//
//  BmobObjectSub.swift
//  BmobSwift
//
//  Created by Bmob on 14-8-7.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

import Foundation

