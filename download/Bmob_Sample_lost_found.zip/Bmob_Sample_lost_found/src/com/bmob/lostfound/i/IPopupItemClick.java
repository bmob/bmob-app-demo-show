package com.bmob.lostfound.i;

import android.view.View;

/** �����༭�ӿ�
  * @ClassName: IPopupItemClick
  * @Description: TODO
  * @author smile
  * @date 2014-5-21 ����3:48:37
  */
public interface IPopupItemClick {
	void onEdit(View v);

	void onDelete(View v);
}
