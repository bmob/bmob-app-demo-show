//
//  AddViewController.h
//  Found+Lost
//
//  Created by Bmob on 14-5-22.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddViewController : UIViewController


-(instancetype)initWithFoundOrNot:(BOOL)found;

@end
