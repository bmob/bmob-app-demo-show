//
//  News.m
//  Found+Lost
//
//  Created by Bmob on 14-5-22.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import "News.h"

@implementation News

@synthesize title    = _title;
@synthesize time     = _time;
@synthesize content  = _content;
@synthesize phoneNum = _phoneNum;


@end
