//
//  News.h
//  Found+Lost
//
//  Created by Bmob on 14-5-22.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface News : NSObject

@property(nonatomic,copy)NSString  *title;
@property(nonatomic,copy)NSString  *content;
@property(nonatomic,copy)NSString  *time;
@property(nonatomic,copy)NSString  *phoneNum;
@end
