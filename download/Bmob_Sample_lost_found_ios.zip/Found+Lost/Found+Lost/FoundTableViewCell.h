//
//  FoundTableViewCell.h
//  Found+Lost
//
//  Created by Bmob on 14-5-22.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoundTableViewCell : UITableViewCell



@property(nonatomic,strong)UILabel  *titleLabel;
@property(nonatomic,strong)UILabel  *contentLabel;
@property(nonatomic,strong)UILabel  *timeLabel;
@property(nonatomic,strong)UIButton *phoneButton;

@end
